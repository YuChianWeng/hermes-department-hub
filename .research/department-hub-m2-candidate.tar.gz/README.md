# Department Hub — department-led orchestration for Hermes Kanban

**Status: M1 v4.1 candidate (library + plugin registration). Not deployed, not
installed into any profile.** v4's behaviour passed an independent re-review; v4.1
closes that review's documentation/contract blockers (P1-C, P2-5, P3) and is
awaiting the lightweight re-review that freezes the external schema. The normative
interface is [docs/m1-v4-contract.md](docs/m1-v4-contract.md); this README is the
operator view of the same contract.

A Hermes plugin that lets a department manager own a slice of a Kanban board:
child events are routed to the department's manager, every processed event gets a
durable receipt, a failed review can never release a deliverable, and at most one
evidenced final append is attempted per accepted task. Unknown outcomes stay held.

## What this slice does

| Capability | Where |
|---|---|
| Plugin manifest + public registration (`register(ctx)`, no I/O at discovery) | `plugin.yaml`, `__init__.py` |
| Department settings + manager/member/reviewer binding, plus runtime caller-profile check | `department_lib/config.py`, `models.py`, `__init__.py` |
| Board-verified root binding + manager wake subscription setup (`department_bind`) | `department_lib/orchestrator.py`, `routing.py` |
| **Artifact producer** — the only source of artifact identity (`department_submit`) | `department_lib/artifacts.py`, `store.py`, `orchestrator.py` |
| Manager wake routing via documented `notify-subscribe --delivery-mode wake` + read-back | `department_lib/routing.py` |
| Kanban as the only task source (documented CLI, strict parsing) | `department_lib/kanban_cli.py`, `board.py` |
| Durable event receipts / idempotency / conflict detection / crash recovery | `department_lib/store.py`, `orchestrator.py` |
| Bounded repair loop + board-verified acceptance gate + explicit accept-then-deliver | `department_lib/acceptance.py`, `orchestrator.py` |
| Single final handoff on the department root card + escalation, no blind resend | `department_lib/delivery.py`, `kanban_effects.py` |

## Layout

```
plugin.yaml                     manifest (tools, hooks, config schema)
__init__.py                     register(ctx) + the 7 tool handlers, lazily built service
department_lib/models.py        Department, BoardEvent identity, canonical JSON
department_lib/config.py        departments: block parsing/validation
department_lib/store.py         plugin-owned SQLite (WAL), receipts, artifacts, deliveries
department_lib/artifacts.py     stdlib-only SHA-256 producer (size/time/realpath)
department_lib/kanban_cli.py    `hermes kanban …` adapter (public commands only)
department_lib/board.py         authoritative, strict board snapshots
department_lib/routing.py       manager wake subscription + read-back
department_lib/acceptance.py    review evidence, repair limit, acceptance gate
department_lib/delivery.py      one final handoff / escalation, reconciliation
department_lib/kanban_effects.py comment effect port with marker read-back
department_lib/orchestrator.py  service facade
docs/m1-v4-contract.md          the frozen-candidate external contract (normative)
tests/                          unit + contract tests
```

## Configuration

```yaml
plugins:
  entries:
    department-hub:
      settings:
        state_path: ~/.hermes/department-hub/state.db
        departments:
          - id: dev
            name: Development
            manager: {profile: dept-manager, platform: api_server, chat_id: api-dev-session}
            members: [worker-a]
            reviewers: [reviewer-a]
            max_repair_rounds: 2
```

The **manager profile must enable the `kanban` toolset**; otherwise the manager is
woken but has no Kanban tools (P0 finding B). The plugin never edits profiles.

## Artifact contract (v4: the producer is the only identity)

`department_submit` is the **only** source of artifact identity. It reads one
local regular file at an absolute path (≤ 64 MiB), hashes it with SHA-256 and
durably records `(task_id, revision, sha256, algorithm, path, real_path,
size_bytes, producer_profile, computed_at)`.

1. **A board declaration is never identity.** `metadata.artifact_sha256` on the
   submission run, on the review run, or in the review-request payload adds no
   authority. Without a producer record every PASS stays `held/artifact_unbound`
   and nothing is released.
2. **A board declaration can only tighten.** If a run or the request payload
   declares a SHA that differs from the producer record, the gate holds
   `artifact_declaration_conflict`; neither byte-history may be delivered.
3. **`department_submit` must be recorded before `department_accept`.** The
   manager's acceptance verifies the producer record for the exact revision, so
   an acceptance that runs first returns `held/artifact_unbound` and records
   nothing.
4. Identity is keyed by `(task_id, revision)`. A different file for the same
   revision is refused (`artifact_identity_conflict`); the recovery path is a new
   revision, never an overwrite. A new revision (after an authorised rejection)
   must be submitted again.
5. **`department_submit` may run after the review, but never after the
   acceptance.** Real reviewers do not call plugin tools, so the worker (or the
   manager) may submit once the reviewed bytes are final. A submit that lands
   after a *held* acceptance does not retroactively authorise anything:
   `department_deliver` requires the recorded acceptance and holds
   `acceptance_missing` until the manager calls `department_accept` again.

> **Limitation you must not misread.** The artifact identity is a hash **the
> worker declared** for the reviewed revision. It is not a reviewer attestation
> that the reviewer saw those bytes, and it is not a byte re-hash at delivery
> time. M2 must not word `ready_to_deliver` — or any acceptance — as "the
> reviewer verified the artifact bytes". See the contract, §8.

## Acceptance contract (what a worker/reviewer must publish)

A work card is submitted with `kanban_request_review(reviewer=<bound reviewer>)`.
That event publishes `implementer` and `reviewer` in its payload; the gate uses
the published implementer (not `task.assignee`, which same-card review moves to
the reviewer) and requires it to be a declared department member.

For a review to be releasable:

* the current reviewer must have a review-lane claim **after** the current review
  request, and must be the requested reviewer and not the implementer;
* the review run must publish a positive verdict — explicit
  `metadata.verdict=PASS` (with an empty or exact canonical PASS summary), or a
  summary whose first line starts with `PASS` / `REVIEW: PASS`;
* friendly prose is **not** evidence: `looks good`, `all checks passed`, `LGTM`,
  `已通過` hold as `review_unproven`;
* any negative token (`not approved`, `changes required`, `REQUEST CHANGES`,
  `changes_requested`, `REJECT`, `未通過`, `不通過`, `駁回`, `退回`, `拒絕`,
  `需修改`) holds as `verdict_conflict`, even next to a structured PASS;
* the artifact identity must exist from `department_submit` (see above).

The manager then runs `department_accept` with the exact
`(task_id, revision, verdict_run_id, artifact_sha256)`; the claim is verified
against the live board and the producer record, and the acceptance row is bound
to that exact evidence. `department_deliver` re-verifies the board *and* requires
that active acceptance — a fresh PASS alone is not enough.

Manager-only tools (`department_accept`, `department_deliver`,
`department_escalate`) require the caller's Hermes profile (`ctx.profile_name`)
to equal the department's configured manager profile. A model cannot self-report
a different identity in arguments.

### Gate reason codes

`department_accept` / `department_deliver` hold with:

`inactive_department`, `manager_mismatch`, `ownership_changed`,
`ownership_unknown`, `ownership_unverified`, `board_unknown`,
`review_rejected`, `repair_loop_exhausted`, `review_generation_stale`,
`verdict_conflict`, `review_unproven`, `rejection_unbound`,
`reviewer_not_independent`, `reviewer_not_requested`, `implementer_not_member`,
`revision_mismatch`, `no_pass_verdict`, `stale_verdict`, `verdict_not_final`,
`event_quarantined`, `artifact_unbound`, `artifact_mismatch`,
`artifact_declaration_conflict`, `acceptance_not_active`.

`department_deliver` can additionally hold with `acceptance_missing`,
`acceptance_stale`, `delivery_identity_conflict`, `effect_fencing_unavailable`,
`effect_transaction_nested`, `department_changed`; unknown deliveries report
`prior_effect_unknown`, `in_flight_unknown`, `readback_unavailable` or
`readback_not_found`.

`department_submit` refuses with `artifact_path_invalid`, `artifact_missing`,
`artifact_not_regular`, `artifact_too_large`, `artifact_unreadable`,
`artifact_changed_while_reading`, `artifact_identity_conflict`,
`caller_unverified`, `caller_not_permitted`, `inactive_department`,
`board_unknown`, `ownership_*`.

The full, authoritative sets are in the contract §4. `not_attempted` and
`event_at_*` are **not** M1 reason codes (the contract §4 names the two
same-named fields that live in the M2 dashboard payload instead).

## Minimal operator flow (submit → review → accept → ready → deliver)

This is the whole happy path; it is also the demo script. `M` = department
manager profile, `W` = member profile, `R` = reviewer profile.

```text
0. Board setup (once per department)
   M  department_bind(department="dev", root_task_id="<root>", task_ids=["<work>"])
      -> {"success": false, "ensured": ["<root>", "<work>"], "routing_ok": false,
          "issues": [{"code": "session_owner_unverified", ...}, ...]}
   `success` is false **by design** here: the ownership rows are written
   (`ensured` names both cards) but public `notify-list` cannot attest the
   runtime session owner, so routing reports `session_owner_unverified`. That is
   the documented wake limitation, not a failed bind — continue. The root must
   be assigned to M on the board, and the work card to W (or R/M), or the bind
   skips that card.

1. Produce and register the reviewed bytes  (BEFORE any acceptance)
   W  department_submit(task_id="<work>", artifact_path="/abs/path/deliverable.md")
      -> {"success": true, "action": "recorded", "revision": 1,
          "artifact": {"sha256": "<64 hex>", "size_bytes": 123, ...}}
   Keep `revision` and `artifact.sha256` — the manager needs both verbatim.

2. Review (plain Kanban; the reviewer publishes a verdict, not a SHA)
   W  kanban_request_review(task_id="<work>", reviewer="R")
   R  claim the review, then complete it with summary "REVIEW: PASS"
      (or `metadata.verdict="PASS"`). Anything friendlier holds as review_unproven.

3. Record the board events (recommended, idempotent)
   M  department_ingest(task_id="<work>")
      -> {"success": true, "revision": 1, "events": [...]}
   `revision` here must equal the revision you submitted for.
   The PASS run id is `runs[].id` of R's completed run in
   `hermes kanban show <work> --json`.

4. Accept the exact evidence  (this is what makes it ready)
   M  department_accept(task_id="<work>", revision=1,
                        verdict_run_id=<PASS run id>,
                        artifact_sha256="<sha from step 1>")
      -> {"success": true, "status": "releasable", "ready_to_deliver": true,
          "artifact_sha256": "...", "reviewer": "R"}
   Any mismatch holds with a reason code above and records no acceptance.

5. Deliver once, by hand
   M  department_deliver(<the same four fields>)
      -> {"success": true, "action": "delivered"}       # exactly one append
   Replay -> {"action": "already_delivered"}             # never a second append
```

Notes that keep the demo honest:

* `ready_to_deliver` is a **readiness** flag: the exact acceptance is durable and
  `department_deliver` *would* be authorised. It is not a claim that bytes were
  re-verified (see the limitation above).
* With the stock `CommentEffectPort` the final handoff holds
  `effect_fencing_unavailable` (no upstream conditional comment write yet). A
  demo that must reach `delivered` uses a fake/local effect port — that is a
  property of the effect transport, not of the acceptance gate.
* One final handoff per (department, task). Once delivered, a later generation
  that accepts as `releasable` still holds `delivery_identity_conflict`; it is
  not a second deliverable (contract §4).

## Tests

```bash
cd product
PYTHONDONTWRITEBYTECODE=1 PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 \
  /home/ubuntu/.hermes/hermes-agent/venv/bin/python -m pytest tests -q -p no:cacheprovider
hermes plugins validate . --json
```

`tests/` uses only the standard library and pytest; no network, no profile writes,
no board writes. All fixtures are synthetic.

## Guarantees and non-guarantees

**Guaranteed (synthetic tests):** idempotent event handling keyed on stable source ID
when available, otherwise conservative board coordinates; one
receipt and at most one effect per event identity, committed atomically with its
domain effect; an event observed without its receipt is re-applied once on the
next ingest only if it has never conflicted; conflicts are sticky-quarantined; a
failed, stale, foreign or non-member review cannot be released; release requires
an explicit manager acceptance of the exact revision/run/SHA **and** a producer
record for that revision; one effective final
append attempt per (department, task), directed to the verified root card and confirmed by
a bounded read-back; an unknown delivery outcome is never blindly resent.

**Not guaranteed — do not claim:**
* **strict exactly-once** delivery to any external system;
* **reviewer attestation of artifact bytes.** The identity is the producer's
  declared hash of the file the worker chose; a submit may follow the review and
  the reviewer never has to see the bytes;
* notification isolation. P0-R run 444 reproduced Kanban's subscription inheritance:
  a coordinator subscribed to a root is woken by child events. This plugin reports a
  foreign subscription as a conflict; it cannot veto core inheritance, because Kanban
  plugin hooks are observer-only and there is no public no-inherit switch;
* runtime session ownership or manager wake. Subscription creation specifies
  `--notifier-profile`, but public notify-list cannot attest the session owner;
  routing returns `session_owner_unverified` even for a matching subscription;
* retry after an unknown/pending delivery: even reconcile holds on absence,
  because upstream has no reliable idempotency/fencing contract;
* shared-board confidentiality (`kanban_show` can expose child metadata);
* authentication of callers. Profile/task/SHA identity is not an ACL;
* real Desktop UI (deferred to M2-R), real-model judgement, or a live gateway run
  under a strict no-network gate (`NOT FEASIBLE`, `t_549898c3`);
* artifact byte immutability: the gate binds the producer's declared SHA, it does
  not re-hash bytes at send time.

## Scope limits of this slice

No deployment, no install into `default`/other profiles, no changes to existing
notifications, board, gateway or FreshTape, no public push, no outbound messages.

M1-v2 interface tightening and caller migration: [docs/m1-v2-contract.md](docs/m1-v2-contract.md).
M1-v4 external contract (normative, v4.1 corrected): [docs/m1-v4-contract.md](docs/m1-v4-contract.md).
