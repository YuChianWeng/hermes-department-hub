"""Boundary, crash and read-model controls for v3. No live systems."""
from contextlib import contextmanager
from copy import deepcopy
from dataclasses import replace
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading

import pytest
from department_lib.acceptance import evidence_from_board
from department_lib.board import Board, BoardError
from department_lib.dashboard import DashboardService
from department_lib.delivery import Delivery, final_key
from department_lib.kanban_effects import CommentEffectPort
from department_lib.orchestrator import DepartmentService
from department_lib.store import Store
from tests.test_m1_v2_regressions import setup, payload, claim, D, A, CLI, Port


def reject(cli):
    cli.tasks['work']['events'].extend([
        {'id':4,'kind':'claimed','created_at':103,'run_id':7,'payload':{'source_status':'review'}},
        {'id':5,'kind':'changes_requested','created_at':104,'run_id':7,'payload':{}}])
    cli.tasks['work']['runs'].append({'id':7,'profile':'reviewer','outcome':'changes_requested',
                                   'status':'done','summary':'Fix it please','metadata':None})


def test_stock_comment_port_requires_upstream_fence_even_after_acceptance(setup):
    st,cli,svc,port=setup
    comments=[]
    cli.comment=lambda *a,**kw: comments.append((a,kw))
    svc.delivery=Delivery(st,CommentEffectPort(cli,['work']))
    assert svc.accept(claim()).status=='releasable'
    result=svc.release(claim())
    assert result.action=='held' and result.reason=='effect_fencing_unavailable'
    assert not comments and st.delivery_count()==0


def test_committed_intent_then_rejection_before_second_transaction_zero_effect(setup):
    st,cli,svc,port=setup
    assert svc.accept(claim()).status=='releasable'
    original=st.transaction; entered,proceed=threading.Event(),threading.Event()
    paused=False; results=[]; errors=[]
    @contextmanager
    def pause_after_claim_commit():
        nonlocal paused
        with original() as conn:
            yield conn
        if (not paused and not st.connection.in_transaction
                and st.get_delivery(final_key('dev','work')) is not None):
            paused=True; entered.set(); assert proceed.wait(8)
    st.transaction=pause_after_claim_commit
    def release():
        try: results.append(svc.release(claim()))
        except BaseException as e: errors.append(e)
    t=threading.Thread(target=release); t.start(); assert entered.wait(8)
    other=Store(st._path)
    try:
        # Intent really is durable/visible before the effect; independent DB.
        assert other.get_delivery(final_key('dev','work')).state=='pending'
        reject(cli)
        DepartmentService(other,svc.board,Delivery(other,port),svc.router).ingest('work')
        assert other.active_acceptance('dev','work') is None
    finally:
        proceed.set(); t.join(8); other.close(); st.transaction=original
    assert not t.is_alive() and not errors
    assert results[0].action=='held' and port.appends==0
    assert st.get_delivery(final_key('dev','work')).state=='dead_letter'


def test_final_effect_observes_durable_intent_and_writer_transaction(setup):
    st,cli,svc,port=setup
    assert svc.accept(claim()).status=='releasable'
    second=Store(st._path); original=port.append; observed=[]
    def append(key,body):
        assert st.connection.in_transaction
        row=second.get_delivery(key)
        assert row is not None and row.state=='pending' and row.body==body
        observed.append(key); original(key,body)
    port.append=append
    try: assert svc.release(claim()).action=='delivered'
    finally: second.close()
    assert observed==[final_key('dev','work')] and port.appends==1


def test_sigkill_after_effect_preserves_intent_and_readback_never_resends(tmp_path):
    root=Path(__file__).parents[1]
    code=r'''
import sys,os,signal,socket,json
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,sys.argv[1])
def deny(*a,**kw): raise RuntimeError('network prohibited')
socket.socket=deny; socket.getaddrinfo=deny; socket.create_connection=deny
from tests.test_m1_v2_regressions import D,CLI,payload,claim
from department_lib.board import Board
from department_lib.store import Store
from department_lib.delivery import Delivery
from department_lib.orchestrator import DepartmentService
folder=Path(sys.argv[2]); st=Store(folder/'crash.db')
st.register_department(D); st.bind_task('dev','work',role='work')
st.put_artifact(task_id='work',revision=1,sha256='a'*64,algorithm='sha256',path='/synthetic/work',
                real_path='/synthetic/work',size_bytes=0,producer_profile='worker',computed_at=0.0)
class Port:
 def append(self,key,body):
  with open(folder/'effect.json','w') as f:
   json.dump({'key':key,'body':body},f); f.flush(); os.fsync(f.fileno())
  os.kill(os.getpid(),signal.SIGKILL)
 def find(self,key): return 'absent'
p=Port(); svc=DepartmentService(st,Board(CLI({'work':payload()})),Delivery(st,p))
assert svc.accept(claim()).status=='releasable'
svc.release(claim())
'''
    result=subprocess.run([sys.executable,'-c',code,str(root),str(tmp_path)],
                          capture_output=True,text=True,timeout=15,
                          env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'})
    assert result.returncode == -signal.SIGKILL, (result.returncode,result.stdout,result.stderr)
    record=json.loads((tmp_path/'effect.json').read_text()); st=Store(tmp_path/'crash.db')
    assert st.get_delivery(record['key']).state=='pending'
    class ReadbackPort:
        appends=0
        def append(self,*a): self.appends+=1; raise AssertionError('must not resend')
        def find(self,key): return 'found' if key==record['key'] else 'absent'
    port=ReadbackPort(); svc=DepartmentService(st,Board(CLI({'work':payload()})),Delivery(st,port))
    try:
        assert svc.release(claim()).action=='already_delivered'
        assert svc.delivery.reconcile('dev','work').action=='already_delivered'
        assert port.appends==0 and st.get_delivery(record['key']).body==record['body']
    finally: st.close()


def test_old_explicit_membership_without_topology_fails_closed(setup):
    st,cli,svc,port=setup
    cli.tasks['root']=payload('root','manager')
    st.bind_task('dev','root',role='root')
    st.bind_membership('dev','work','root',())  # old schema lacks fingerprint
    assert svc.accept(claim()).reason=='ownership_unknown'
    assert svc.release(claim()).action=='held' and not port.entries


def test_detached_explicit_root_ancestry_is_also_revalidated(setup):
    st,cli,svc,port=setup
    cli.tasks['root']=payload('root','manager')
    svc.bind_department('dev','root',['work'])
    assert svc.accept(claim()).status=='releasable'
    cli.tasks['middle']=payload('middle','worker')
    cli.tasks['root']['parents']=['middle']
    assert svc.accept(claim()).reason=='ownership_changed'
    assert svc.release(claim()).action=='held' and not port.entries


@pytest.mark.parametrize('fault',['submission_absent','submission_sha_absent','structured_pass','free_summary'])
def test_authoritative_rejection_never_lost_to_optional_provenance(setup,fault):
    st,cli,svc,port=setup
    r=cli.tasks['work']['runs'][1]
    r.update(outcome='changes_requested',summary='fix',metadata=None)
    if fault=='submission_absent': cli.tasks['work']['runs'].pop(0)
    elif fault=='submission_sha_absent': cli.tasks['work']['runs'][0]['metadata']=None
    elif fault=='structured_pass': r['metadata']={'verdict':'PASS'}
    else: r['summary']='REVIEW: PASS (but outcome rejects)'
    assert svc.accept(claim()).reason=='review_rejected'
    assert svc.release(claim()).reason=='review_rejected' and not port.entries


def test_shared_raw_helpers_do_not_manufacture_provenance():
    from tests.support import task,run,event,dept,SHA
    request=run(5,'worker-a','review_requested')
    reviewer=run(6,'reviewer-a','done',outcome='completed',artifact_sha256=SHA)
    events=[event('review_requested',200,5,reviewer='reviewer-a',implementer='worker-a')]
    snap=task(events=events,runs=[request,reviewer])
    assert snap.events==tuple(events) and snap.runs==(request,reviewer)
    assert request.outcome is None and request.metadata is None
    assert reviewer.summary is None and reviewer.metadata=={'artifact_sha256':SHA}
    assert evidence_from_board(dept(),snap).verdict is None


def test_raw_missing_provenance_dashboard_is_not_pass(tmp_path):
    from tests.support import task,run,event,dept,SHA,FakeBoard
    st=Store(tmp_path/'readmodel.db'); st.register_department(dept()); st.bind_task('dev','t1',role='work')
    snap=task(events=[event('review_requested',200,5,reviewer='reviewer-a',implementer='worker-a')],
              runs=[run(5,'worker-a','review_requested'),run(6,'reviewer-a','done',outcome='completed',artifact_sha256=SHA)])
    try:
        view=DashboardService(st,FakeBoard({'t1':snap}),ttl=0).department('dev')
        entry=view['department']['tasks'][0]
        assert entry['review']['verdict'] == 'NONE'
        assert entry['acceptance'] is None and entry['final_report'] is None
    finally: st.close()


def test_dead_letter_different_identity_preserves_stored_body(setup):
    st,cli,svc,port=setup
    assert svc.accept(claim()).status=='releasable'
    key=final_key('dev','work'); st.put_delivery(key,'dev','work','final',{})
    st.set_delivery_state(key,'dead_letter','operator must intervene')
    result=svc.release(claim())
    assert result.action=='held' and result.reason=='delivery_identity_conflict'
    assert st.get_delivery(key).body=={} and st.get_delivery(key).state=='dead_letter'
    assert port.appends==0
